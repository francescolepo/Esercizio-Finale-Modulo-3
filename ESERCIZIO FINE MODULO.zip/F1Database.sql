CREATE DATABASE Formula1DB;
USE Formula1DB;


CREATE TABLE Team (
    team_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    sede VARCHAR(255),
    anno_fondazione INT
);


CREATE TABLE Pilota (
	pilota_id INT AUTO_INCREMENT PRIMARY KEY,
    numero_corsa INT,
    nome VARCHAR(255) NOT NULL,
    data_nascita DATE,
    nazionalita VARCHAR(50),
    team_id INT,
    FOREIGN KEY (team_id) REFERENCES Team(team_id)
);


CREATE TABLE Circuito (
    circuito_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    localita VARCHAR(255),
    lunghezza DECIMAL(5, 3)
);


CREATE TABLE Gara (
    gara_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    circuito_id INT,
    data DATE,
    FOREIGN KEY (circuito_id) REFERENCES Circuito(circuito_id)
);


CREATE TABLE Punteggio (
    posizione INT PRIMARY KEY,
    punti INT
);


CREATE TABLE Risultato (
    risultato_id INT AUTO_INCREMENT PRIMARY KEY,
    gara_id INT,
    pilota_id INT,
    posizione INT,
    miglior_giro BOOLEAN,
    FOREIGN KEY (gara_id) REFERENCES Gara(gara_id),
    FOREIGN KEY (pilota_id) REFERENCES Pilota(pilota_id),
    FOREIGN KEY (posizione) REFERENCES Punteggio(posizione)
);


INSERT INTO Team (nome, sede, anno_fondazione)
VALUES
    ('Scuderia Ferrari', 'Italia', 1947),
    ('Mercedes-AMG Petronas Formula One Team', 'Regno Unito', 2010),
    ('Red Bull Racing', 'Regno Unito', 2004);

INSERT INTO Pilota (nome, numero_corsa, data_nascita, nazionalita, team_id)
VALUES
    ('Lewis Hamilton', 44, '1985-01-07', 'Regno Unito', 2),
    ('Sebastian Vettel', 5, '1987-07-03', 'Germania', 1),
    ('Max Verstappen', 1, '1997-09-30', 'Paesi Bassi', 3),
    ('Charles Leclerc', 16, '1997-10-16', 'Monaco', 1);
    
INSERT INTO Circuito (nome, localita, lunghezza)
VALUES
    ('Circuit de Barcelona-Catalunya', 'Montmelo, Spagna', 4.655),
    ('Silverstone Circuit', 'Silverstone, Regno Unito', 5.891),
    ('Monza Circuit', 'Monza, Italia', 5.793),
    ('Red Bull Ring', 'Spielberg, Austria', 4.318);
    
INSERT INTO Gara (nome, circuito_id, data)
VALUES
    ('Gran Premio de España', 1, '2023-05-07'),
    ('British Grand Prix', 2, '2023-07-16'),
    ('Italian Grand Prix', 3, '2023-09-03'),
    ('Austrian Grand Prix', 4, '2023-06-25');
    
    
INSERT INTO Punteggio (posizione, punti)
VALUES
    (1, 25),
    (2, 18),
    (3, 15),
    (4, 12);
   
-- Gara 1: Gran Premio de España
INSERT INTO Risultato (gara_id, pilota_id, posizione, miglior_giro)
VALUES
    (1, 1, 1, 1),  -- Lewis Hamilton, 1° posto, Miglior giro
    (1, 2, 3, 0),  -- Sebastian Vettel, 3° posto, Non ha fatto il miglior giro
    (1, 3, 2, 0),  -- Max Verstappen, 2° posto, Non ha fatto il miglior giro
    (1, 4, 4, 0);  -- Charles Leclerc, 4° posto, Non ha fatto il miglior giro

-- Gara 2: British Grand Prix
INSERT INTO Risultato (gara_id, pilota_id, posizione, miglior_giro)
VALUES
    (2, 1, 2, 0),  -- Lewis Hamilton, 2° posto, Non ha fatto il miglior giro
    (2, 2, 4, 0),  -- Sebastian Vettel, 4° posto, Non ha fatto il miglior giro
    (2, 3, 1, 1),  -- Max Verstappen, 1° posto, Miglior giro
    (2, 4, 3, 0);  -- Charles Leclerc, 3° posto, Non ha fatto il miglior giro




