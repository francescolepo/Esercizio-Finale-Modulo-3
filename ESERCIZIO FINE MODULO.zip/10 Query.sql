-- 1. trova il nome e il numero di corsa dei piloti che hanno vinto almeno una gara e che hanno fatto anche il giro veloce
select p.nome, p.numero_corsa, r.posizione	
from pilota as p
join risultato as r on p.pilota_id = r.pilota_id
where r.posizione = 1 AND r.miglior_giro = TRUE;

-- 2. trova i piloti nati nel regno unito o in germania
select nome, nazionalita
from pilota
where nazionalita in ("Regno Unito", "Germania");

-- 3. trova i piloti e i numero di corsa della scuderia ferrari
select p.nome, p.numero_corsa, t.nome as scuderia
from pilota as p
join team t on p.team_id = t.team_id
where t.nome = "Scuderia Ferrari";

-- 4 trova per ogni pilota la sua posizione al primo gran premio (spagna)
select p.nome, r.posizione, g.nome as nome_gara
from pilota as p
join risultato r on p.pilota_id = r.pilota_id
join gara g on g.gara_id = r.gara_id
where r.gara_id = 1
order by r.posizione;

-- 5 trova i punti guadagnati da ciascun pilota alla seconda gara
select p.nome, pg.punti, g.nome as nome_gara
from pilota as p
join risultato r on p.pilota_id = r.pilota_id
join punteggio pg on r.posizione = pg.posizione
join gara g on g.gara_id = r.gara_id
where r.gara_id = 2
order by pg.punti DESC;

-- 6 trova i punti totali ottenuti dai piloti in tutte le gare
select p.nome, sum(pg.punti) as punti_totali
from pilota as p
join risultato as r on p.pilota_id = r.pilota_id
join punteggio as pg on r.posizione = pg.posizione
group by p.nome
order by punti_totali DESC;

-- 7 trova i punti totali ottenuti dalle scuderie in tutte le gare
select t.nome, sum(pg.punti) as punti_totali
from pilota as p
join risultato as r on p.pilota_id = r.pilota_id
join punteggio as pg on r.posizione = pg.posizione
join team as t on t.team_id = p.team_id
group by t.nome
order by punti_totali DESC;

-- 8 trova il numero di piloti delle scuderie ferrari e red bull
select t.nome as scuderia, count(*) as numero_piloti
from team as t 
join pilota as p on t.team_id = p.team_id
group by t.nome
having t.nome in ("Scuderia Ferrari", "Red Bull Racing");

-- 9 trova le gare che si sono svolte a maggio nel 2023
select nome, data
from gara
where YEAR(gara.data) = 2023 AND MONTH(gara.data) = 5;

-- 10 trova tutti i piloti che sono nati nel 1997
select t.nome as scuderia, p.nome, YEAR(p.data_nascita) as anno_nascita
from pilota as p
join team t on p.team_id = t.team_id
where YEAR(p.data_nascita) = 1997;



